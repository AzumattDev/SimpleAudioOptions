| `Version` | `Update Notes`                         |
|-----------|----------------------------------------|
| 1.0.2     | - Courtesy update for Valheim 0.217.46 |
| 1.0.0     | - Initial Release                      |